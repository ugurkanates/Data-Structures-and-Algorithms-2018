package CS222HW1;

import java.util.Random;
import java.util.Scanner;

public class main {
    // for CSV Management and TOTAL system usage for a receptionist could handle.

    public static void main(String[] args) {


        System.out.println("\n" +
                "\n" +
                "         .\n" +
                "      .                    |~~             .\n" +
                "                  .     ___|___      .\n" +
                "                       ((((())))\n" +
                "          .           (((((()))))         .\n" +
                "                    |-------------|\n" +
                "              +    I_I_I_I_I_I_I_I_I    +\n" +
                "             (()   |---------------|   (()\n" +
                "            |---|  ||-| |-| |-| |-||  |---|\n" +
                "  _________|-----|_|---------------|_|-----|_________\n" +
                "  I_I_I_I_I_I_I_I|I_I_I_I_I_I_I_I_I_I|I_I_I_I_I_I_I_|\n" +
                "  |-------|------|-------------------|------|-------|\n" +
                "  ||-| |-||  |-| ||-| |-| |-| |-| |-|| |-|  ||-| |-||\n" +
                "((|-------|------|-------------------|------|-------|))\n" +
                "()|  |_|  |  |_| |::::: ------- :::::| |_|  |  |_|  |()\n" +
                "))|  |_|  |  |_| | |_| |_.-\"-._| |_| | |_|  |  |_|  |((\n" +
                "()|-------|------| |_| | | | | | |_| |------|-------|()\n" +
                "@@@@@@@@@@@@@@@@@|-----|_|_|_|_|-----|@@@@@@@@@@@@@@@@@\n" +
                "           @@@@/=============\\@@@@\n" +
                "                       /       \\");

        System.out.println("Welcome Hotel GTU Management System Version 1.0"); // Display the string.
        System.out.println();
        Menu game = new Menu();
        game.main();
    }



}
