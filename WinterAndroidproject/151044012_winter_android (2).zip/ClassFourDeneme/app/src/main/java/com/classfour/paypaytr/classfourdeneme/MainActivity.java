package com.classfour.paypaytr.classfourdeneme;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.ColorInt;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.RadioButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import static com.classfour.paypaytr.classfourdeneme.R.id;

public class MainActivity extends AppCompatActivity {
    private cellBoard board = null;
    private TextView colorBoard[][];
    private RadioButton p1_icon,p2_icon;
    private TextView resetButton;



    private int moveCount = 0, xloc = 0, yloc = 0;
    private String mark = "RED", pmark = "BLUE", now = null;

    private boolean isOver = false;
    boolean isOverAI = false;
    private boolean oyunSec ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
       try {
           super.onCreate(savedInstanceState);

           setContentView(R.layout.activity_main);
           //getActionBar().hide();
           initColor();
           board = new cellBoard();
           oyunSec = getIntent().getBooleanExtra("oyunsecici", false);
           p1_icon = (RadioButton) findViewById(id.radio_player1);
           p2_icon = (RadioButton) findViewById(id.radio_player2);
           resetButton = (TextView) findViewById(id.Reset);
           resetButton.setOnClickListener(new View.OnClickListener() {
                                              @Override
                                              public void onClick(View v) {
                                                  Intent intent = getIntent();
                                                  finish();
                                                  startActivity(intent);

                                              }
                                          }
           );
       }
       catch (ArrayIndexOutOfBoundsException exception){
           Intent intent = getIntent();
           finish();
           startActivity(intent);
       }


    }

    private void initColor() {
        colorBoard = new TextView[5][5];

        colorBoard[0][0] = (TextView) findViewById(R.id.cell11);
        colorBoard[0][1] = (TextView) findViewById(R.id.cell12);
        colorBoard[0][2] = (TextView) findViewById(R.id.cell13);
        colorBoard[0][3] = (TextView) findViewById(R.id.cell14);
        colorBoard[0][4] = (TextView) findViewById(R.id.cell15);
        colorBoard[1][0] = (TextView) findViewById(R.id.cell21);
        colorBoard[1][1] = (TextView) findViewById(R.id.cell22);
        colorBoard[1][2] = (TextView) findViewById(R.id.cell23);
        colorBoard[1][3] = (TextView) findViewById(R.id.cell24);
        colorBoard[1][4] = (TextView) findViewById(R.id.cell25);
        colorBoard[2][0] = (TextView) findViewById(R.id.cell31);
        colorBoard[2][1] = (TextView) findViewById(R.id.cell32);
        colorBoard[2][2] = (TextView) findViewById(R.id.cell33);
        colorBoard[2][3] = (TextView) findViewById(R.id.cell34);
        colorBoard[2][4] = (TextView) findViewById(R.id.cell35);
        colorBoard[3][0] = (TextView) findViewById(R.id.cell41);
        colorBoard[3][1] = (TextView) findViewById(R.id.cell42);
        colorBoard[3][2] = (TextView) findViewById(R.id.cell43);
        colorBoard[3][3] = (TextView) findViewById(R.id.cell44);
        colorBoard[3][4] = (TextView) findViewById(R.id.cell45);
        colorBoard[4][0] = (TextView) findViewById(R.id.cell51);
        colorBoard[4][1] = (TextView) findViewById(R.id.cell52);
        colorBoard[4][2] = (TextView) findViewById(R.id.cell53);
        colorBoard[4][3] = (TextView) findViewById(R.id.cell54);
        colorBoard[4][4] = (TextView) findViewById(R.id.cell55);



    }

            public void cellClick(View v) {
                try {
                    //Get the id of the clicked object and assign it to a Textview variable
                    TextView cell = (TextView) findViewById(v.getId());
                    //Check the content and make sure the cell is empty and that the game isn't over
                    String content = (String) cell.getText();
                    if (content == "" && !isOver && !isOverAI) {

                        //Find the X Y location values of the particular cell that was clicked
                        switch (cell.getId()) {

                            case R.id.cell11:
                                xloc = 0;
                                break;
                            case R.id.cell12:
                                xloc = 1;
                                break;
                            case R.id.cell13:
                                xloc = 2;
                                break;
                            case R.id.cell14:
                                xloc = 3;
                                break;
                            case R.id.cell15:
                                xloc = 4;
                                break;
                            case R.id.cell21:
                                xloc = 0;
                                break;
                            case R.id.cell22:
                                xloc = 1;
                                break;
                            case R.id.cell23:
                                xloc = 2;
                                break;
                            case R.id.cell24:
                                xloc = 3;
                                break;
                            case R.id.cell25:
                                xloc = 4;
                                break;
                            case R.id.cell31:
                                xloc = 0;
                                break;
                            case R.id.cell32:
                                xloc = 1;
                                break;
                            case R.id.cell33:
                                xloc = 2;
                                break;
                            case R.id.cell34:
                                xloc = 3;
                                break;
                            case R.id.cell35:
                                xloc = 4;
                                break;
                            case R.id.cell41:
                                xloc = 0;
                                break;
                            case R.id.cell42:
                                xloc = 1;
                                break;
                            case R.id.cell43:
                                xloc = 2;
                                break;
                            case R.id.cell44:
                                xloc = 3;
                                break;
                            case R.id.cell45:
                                xloc = 4;
                                break;
                            case R.id.cell51:
                                xloc = 0;
                                break;
                            case R.id.cell52:
                                xloc = 1;
                                break;
                            case R.id.cell53:
                                xloc = 2;
                                break;
                            case R.id.cell54:
                                xloc = 3;
                                break;
                            case R.id.cell55:
                                xloc = 4;
                                break;


                        }
                        if (moveCount % 2 == 0) {
                            now = mark;
                            //cell.setBackgroundColor(Color.RED);
                        } else if (oyunSec) {
                            now = pmark;
                            //cell.setBackgroundColor(Color.BLUE);

                        }

                        int y = board.placeMark(xloc, now);


                        if (moveCount % 2 == 0) {
                            now = mark;
                            colorBoard[y][xloc].setBackgroundColor(Color.RED);
                            p1_icon.setChecked(false);
                            p2_icon.setChecked(true);
                            moveCount++;

                        } else if (oyunSec) {
                            now = pmark;
                            colorBoard[y][xloc].setBackgroundColor(Color.BLUE);
                            p1_icon.setChecked(true);
                            p2_icon.setChecked(false);
                            moveCount++;


                        }
                        //cell.setText(now);

                        isOver = checkEnd(now);

                        if (!oyunSec && moveCount % 2 == 1) { // yapay zeka modu
                            now = pmark;
                            int ai_oyna = board.ai_answer();
                            y = board.placeMark(ai_oyna, now);

                            colorBoard[y][ai_oyna].setBackgroundColor(Color.BLUE);
                            p1_icon.setChecked(true);
                            p2_icon.setChecked(false);
                            moveCount++;
                            isOverAI = checkEnd(now);


                        }




                    }
                }
                catch (ArrayIndexOutOfBoundsException exception){
                    Toast toast = Toast.makeText(this,R.string.nopls, Toast.LENGTH_SHORT);
                    toast.show();
                    /*Intent intent = getIntent();
                    finish();
                    startActivity(intent);
                    */
                }

    }

    private boolean
    checkEnd(String player) {
//Checks the virtual board for a winner if there's a winner announce it with the provided player
        if (board.check_gamewon(player)) {

            announce(true, player);
            Intent intent = getIntent();
            finish();
            startActivity(intent);

            return true;
        }

//Check to see if we've reached our move total meaning it's a draw
        else if (moveCount >= 25) {

            announce(false, player);
            Intent intent = getIntent();
            finish();
            startActivity(intent);
            return true;

        }
//If neither win or draw then the game is still on
        return false;


    }

    private void announce(boolean b, String player) {
        if (b == true)

            player = player + " wins!";

        else

            player = "It's a draw!";

//Get the application Context and setup the Toast notification with the end state info
        Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, player, Toast.LENGTH_LONG);
        toast.show();
    }
}



