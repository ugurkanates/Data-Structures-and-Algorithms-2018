package com.classfour.paypaytr.classfourdeneme;

import android.support.v7.app.AppCompatActivity;


import java.util.Random;

/**
 * Created by paypaytr on 2/4/18.
 */

public class cellBoard {
    private final int row = 5 ;
    private final int column = 5;
    private String mark = "RED", pmark = "BLUE";
    private String[][] theBoard = new String[50][50]; //board restrictions dont forgt to not get

                                                            //exceptions
    cellBoard() {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                theBoard[i][j] = "";
            }
        }
    }

    public void clear() {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                theBoard[i][j] = "";
            }
        }

    }
    public String[][] getBoard() {
        return theBoard;

    }
    public int placeMark(int xloc,String mark) {
        for(int i = row-1; i >= 0 ; --i ){

            if (theBoard[i][xloc] == "") {
                theBoard[i][xloc] = mark;
                return i;
            }


        }
        return -99;
    }

    public boolean check_gamewon(String player) {

        for(int i = 0 ; i < row ; i++){
            for(int j = 0 ; j < column ; j++){
                    if(theBoard[i][j] == player &&
                            theBoard[i+1][j] == player  &&
                            theBoard[i+2][j] == player &&
                            theBoard[i+3][j] == player && theBoard[i][j]!="")
                        return true;
                    else if(theBoard[i][j] == player &&
                            theBoard[i][j+1] == player  &&
                            theBoard[i][j+2] == player &&
                            theBoard[i][j+3] == player && theBoard[i][j]!="")
                        return true;
                    else if(theBoard[i][j] == player &&
                            theBoard[i+1][j+1] == player  &&
                            theBoard[i+2][j+2] == player &&
                            theBoard[i+3][j+3] == player && theBoard[i][j]!="")
                        return true;
            }

        }
        return false;
    }

    public int ai_answer() {
        //if enemy has 3 move ( near done) then block him
        // first move is random probably
        // otherwise try to get own game done ,aka compelting 4 thing
        //try to find which would be best place? how idk yet.
        //otherwise will see wwhen to write


        //srand (time(NULL)); --> java equvilaent


        int xsayisi_ilk = 0;
        int won = 0; //local tehdit sayisi
        int maxwon = 0; //max tehdit sayısı.
        //int availablej;
        //int availablei;

        //sanirim error eskiden misal 5 diyorduk getuser row 5e kdr donuyodu şimdi 5 diyoruz 6 alıyor
        //cizgide 0-1--12 yıldız var 13 alıyor aslında dogru bir daha bakalım ama oburu yanlısta olbilir
        Random rand = new Random();
        int random = 0;

        for (int i = 0; i < row; i++)
            for (int j = 0; j < column; j++)
                if (theBoard[i][j] == mark) {
                    xsayisi_ilk++;
                } //hence enemy ?
        if (xsayisi_ilk == 1) {
            random = rand.nextInt(column-1);
            return random;
        }
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                if (theBoard[i][j] == mark &&
                        theBoard[i + 1][j] == mark &&
                        theBoard[i + 2][j] == mark &&
                        theBoard[i][j] != "")
                    if(i+3<row) return i + 3;
                else if (theBoard[i][j] == mark &&
                        theBoard[i][j + 1] == mark &&
                        theBoard[i][j + 2] == mark &&
                        theBoard[i][j] != "")
                    if(j+3<row) return j + 3;
                else if (theBoard[i][j] == mark &&
                        theBoard[i + 1][j + 1] == mark &&
                        theBoard[i + 2][j + 2] == mark &&
                        theBoard[i][j] != "")
                    if(j+3<row) return j + 3;
            }
        }

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < column; j++) {
                    if (theBoard[i][j] == pmark &&
                            theBoard[i + 1][j] == pmark &&
                            theBoard[i + 2][j] == pmark &&
                            theBoard[i][j] != "")
                        if(i+3<row) return i + 3;
                    else if (theBoard[i][j] == pmark &&
                            theBoard[i][j + 1] == pmark &&
                            theBoard[i][j + 2] == pmark &&
                            theBoard[i][j] != "")
                        if(j+3<row) return j + 3;
                    else if (theBoard[i][j] == pmark &&
                            theBoard[i + 1][j + 1] == pmark &&
                            theBoard[i + 2][j + 2] == pmark &&
                            theBoard[i][j] != "")
                        if(j+3<row) return j + 3;
                }


            }
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                if (theBoard[i][j] == pmark &&
                        theBoard[i + 1][j] == pmark &&
                        theBoard[i][j] != "")
                    if(i+2<row) return i + 2;
                else if (theBoard[i][j] == pmark &&
                        theBoard[i][j + 1] == pmark &&
                        theBoard[i][j] != "")
                    if(j+2<row) return j + 2;
                else if (theBoard[i][j] == pmark &&
                        theBoard[i + 1][j + 1] == pmark &&
                        theBoard[i][j] != "")
                    if(j+2<row) return j + 2;
            }


        }
        return rand.nextInt(column-1); // temp


    }
    }