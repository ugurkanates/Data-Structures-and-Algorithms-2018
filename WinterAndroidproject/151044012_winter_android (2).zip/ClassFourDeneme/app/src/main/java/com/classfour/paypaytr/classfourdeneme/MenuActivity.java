package com.classfour.paypaytr.classfourdeneme;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;

public class MenuActivity extends AppCompatActivity {
    private RadioButton startp1_icon,startp2_icon;
    private ImageView startp3_icon;
    private boolean sent_intent = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        startp1_icon = (RadioButton) findViewById(R.id.start_radio_player1);
        startp1_icon.setOnClickListener(new View.OnClickListener() {
                                           @Override
                                           public void onClick(View v) {
                                               startp1_icon.setChecked(true);
                                               startp2_icon.setChecked(false);
                                               sent_intent = true;
                                           }
                                       }
        );
        startp2_icon = (RadioButton) findViewById(R.id.start_radio_player2);
        startp2_icon.setOnClickListener(new View.OnClickListener() {
                                           @Override
                                           public void onClick(View v) {
                                               startp2_icon.setChecked(true);
                                               startp1_icon.setChecked(false);
                                               sent_intent = false;

                                           }
                                       }
        );
        startp3_icon = (ImageView)findViewById(R.id.start_radio_player3);
        startp3_icon.setOnClickListener(new View.OnClickListener() {
                                           @Override
                                           public void onClick(View v) {
                                               Intent intent =new Intent(MenuActivity.this,MainActivity.class);
                                               intent.putExtra("oyunsecici",sent_intent);
                                               startActivity(intent);

                                           }
                                       }
        );
    }
}
